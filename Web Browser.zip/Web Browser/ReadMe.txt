Title:-
Get Connected (Web Browser)


Description:-

Get Connected is an advanced web browser written in Visual Basic .Net using .Net Framework 3.5 (Visual Studio 2013). 
It is a tabbed web browser and integrate with Microsoft Internet Explorer or Edge browser, to display web accurately 
the web page is rendered by Microsoft base browser engine. It supports all the modern web standards including HTML5, CSS3 
and JavaScript etc. In general it supports the same web standards as Google Chrome, Mozilla Firefox and other modern web browsers. 

It shows many examples of working with the new browser control and the loaded document. Using simple features such as 
navigation, history, bookmarks, page source, options, print page, save page and other small things to keep memory usage down. 
It�s also have some latest features such as YouTube video downloading, Ctrl key function add the Prefix www. & append .com 
to the text in the address bar, and then load the website. For example, type yahoo into the address bar and 
press Ctrl key to open www.yahoo.com.
 
It provides the fastest and simplest browsing abilities.


System Requirements:-

* Windows operating system
* Pentium IV or higher
* 500MB available space
* Internet Explorer 11 Compatible
* .Net Framework 3.5
* Windows Installer 4.5
